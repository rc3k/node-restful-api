
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'rwpickering',
  applicationName: 'node-restful-api-app',
  appUid: '4z3jZVVbFLDnKQXLZ3',
  orgUid: '8X3xx7y0y7wDFj3zpK',
  deploymentUid: 'ffe3a32d-df08-4aa5-b8cb-cd69ade84a2e',
  serviceName: 'node-restful-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'node-restful-api-dev-app', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}